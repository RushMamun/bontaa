
<!DOCTYPE html>
<html lang="en">
<head>
	<meta property="og:description" content="Lindo App allows you to play Dofus Touch on PC (Windows, Mac OS, Linux), without running a heavy Android emulator">
	<meta name="twitter:description" content="Lindo App allows you to play Dofus Touch on PC (Windows, Mac OS, Linux), without running a heavy Android emulator">
	<meta name="description" content="Lindo App allows you to play Dofus Touch on PC (Windows, Mac OS, Linux), without running a heavy Android emulator">
	<meta property="og:title" content="Lindo App: The way to play DOFUS Touch on your PC" />
	<meta name="twitter:title" content="Lindo App: The way to play DOFUS Touch on your PC" />
	<title>Lindo App: The way to play DOFUS Touch on your PC</title><meta charset=utf-8>
	<meta http-equiv=X-UA-Compatible content="IE=edge"><meta name=viewport content="width=device-width,initial-scale=1"><link rel=icon href=/favicon.ico><meta name=twitter:card content=summary>
	<meta name=twitter:site content=@Lindo_Officiel>
	<meta name=twitter:image content=https://lindo-app.com/icon.png>
	<meta property=og:type content=profile>
	<meta property=og:image content=https://lindo-app.com/icon.png>
	<meta property=og:image:type content=image/png>
	<meta property=og:image:width content=77>
	<meta property=og:image:height content=106>
	<meta property=og:site_name content="Lindo No-Emu: Play Dofus Touch on PC">
	<meta name=theme-color content=#21201d>
	<style>
    	body {
        background-color: #21201d;
      }
	</style>
	<link href="/css/help.77d3f7b0.css" rel=prefetch>
	<link href=/js/help.75e2285a.js rel=prefetch>
	<link href=/js/lang-de-js.603991f3.js rel=prefetch>
	<link href=/js/lang-es-js.581a252c.js rel=prefetch>
	<link href=/js/lang-it-js.e20c403e.js rel=prefetch>
	<link href=/js/lang-pl-js.f7d6b14b.js rel=prefetch>
	<link href=/js/lang-tr-js.af5f3b3f.js rel=prefetch>
	<link href=/css/app.b13156e5.css rel=preload as=style>
	<link href=/js/app.77f86cba.js rel=preload as=script>
	<link href=/js/chunk-vendors.95a03681.js rel=preload as=script>
	<link href=/css/app.b13156e5.css rel=stylesheet>
</head>

  <body>
  	<noscript>
  		<strong>We're sorry but Lindo No-Emu doesn't work properly without JavaScript enabled. Please enable it to continue.</strong>
  	</noscript>
  	<div id=app></div>
  	<script src=/js/chunk-vendors.95a03681.js></script>
  	<script src=/js/app.77f86cba.js></script>
  </body>
  </html>